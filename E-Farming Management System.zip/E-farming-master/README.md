# E-Farming
<h1>Introduction</h1>
E-Farming is a distributed application, developed to provide a simple and easy way to trade agricultural products produced by the farmers and to educate farmers by providing information about proper cultivation methods. The application is maintained among the four stakeholders,admin,farmers,Agricultural Officer and customers. It provides guidance and maintains information about all cultivated crops of farmers, payment details of customers, climate and soil information suggested by agricultural officer for a particular crop. As it is user friendly, it is simple to understand by stakeholders and just asks the user to follow step by step operations by giving him options. To implement the project, some open source tools have been used such as XAMPP, CodeIgniter Framework, Apache as web server. The web programing language used to implement this project are HTML(Hypertext Markup Language), CSS(Cascading Style Sheets), JavaScript, JQuery and PHP. MySQL is used as database server. For further enhancement or development of this software, Newsfeed related to agriculture will be considered.
<h2>Objective:</h2>
The main objective of this project is building a website which will help farmers to sell their products.It is a computerized approach for better and clear marketing.This web site will provide a simple platform for farmers and customers to trade agricultural products and also guide farmers by providing information about climatic conditions,soil,fertilizers and pesticides so that they can reach maximum profits.
<h1>Stake holders:</h1>
*	Farmers(Seller)<br>
*	Buyers<br>
*	Agricultural Officer<br>

